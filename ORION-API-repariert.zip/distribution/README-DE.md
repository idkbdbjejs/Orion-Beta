# ORION V1 Beta – Installationspaket

Dieses Paket erzeugt ORION für Android, Windows, macOS und Linux. ORION enthält keinen gemeinsamen Entwickler- oder OpenAI-API-Schlüssel. Vor Online-KI meldet sich jeder Nutzer mit seinem eigenen Puter-Konto an. Die Apps öffnen die aktuelle, zentral aktualisierte ORION-Version von Spectrum X.

## Am einfachsten: direkt installieren

Öffne `https://orion-v1-beta.barysyt907.chatgpt.site`.

- Android/Windows/macOS/Linux: Im Browser auf **Installieren** klicken.
- iPhone/iPad: In Safari **Teilen** → **Zum Home-Bildschirm**.

Das ist sofort nutzbar und aktualisiert sich automatisch.

## Eigene APK und Desktop-Dateien automatisch bauen

1. Erstelle auf GitHub ein leeres Repository, zum Beispiel `ORION-App`.
2. Entpacke dieses ZIP-Paket und lade **alle enthaltenen Ordner und Dateien** in das Repository hoch.
3. Öffne im Repository den Bereich **Actions**.
4. Wähle **ORION Installer bauen** und dann **Run workflow**.
5. Nach dem Build findest du unten unter **Artifacts**:
   - `ORION-Android-APK`
   - `ORION-Windows`
   - `ORION-macOS`
   - `ORION-Linux`
   - `ORION-iOS-Xcode`

Für Android die ZIP-Datei entpacken und `ORION-V1-Beta.apk` antippen. Android fragt einmalig, ob Apps aus dieser Quelle installiert werden dürfen.

Die Android-APK enthält zusätzlich den ORION-Standbydienst und „ORION Geräteaktionen“. Aktiviere in den Android-Bedienungshilfen ausschließlich **ORION Geräteaktionen**. Danach kann ORION per Sprache installierte Apps öffnen, Text in das aktive Feld einsetzen, Zurück/Home/Letzte Apps/Benachrichtigungen/Scrollen ausführen und ausschließlich eine eindeutig sichtbare Schaltfläche „In den Warenkorb“ anklicken. Der Gaming Coach nutzt nach der sichtbaren Android-Systemfreigabe eine MediaProjection-Sitzung für periodische Frames; solange sie läuft, zeigt Android dauerhaft eine Benachrichtigung mit **STOPP** an. Absenden, „Jetzt kaufen“, Checkout und Bezahlen bleiben gesperrt, bis du selbst bestätigst.

Die Desktop-App kann unterstützte System-Apps und Webseiten öffnen sowie Text über die Zwischenablage in die vorher aktive App einsetzen. macOS fragt dafür nach Bedienungshilfen-Zugriff. Unter Linux muss für automatisches Einfügen `xdotool` installiert sein. Eine normale Browser- oder iOS-App darf andere Apps aus Sicherheitsgründen nicht vollständig fernsteuern; dort nutzt ORION Deep Links, Entwürfe, Zwischenablage und Systemdialoge.

## Wichtiger Hinweis zu Apple und Signaturen

Eine auf beliebigen iPhones installierbare `.ipa` muss mit einem Apple-Developer-Konto und einem Zertifikat signiert werden. Ohne diese Apple-Freigabe kann niemand eine dauerhaft installierbare IPA erzeugen. Das Workflow-Paket erstellt deshalb ein Xcode-Projekt; die sofortige Variante auf iOS ist die Home-Screen-App aus Safari.

Windows und macOS zeigen bei unsignierten Testversionen möglicherweise eine Sicherheitswarnung. Für eine öffentliche Veröffentlichung braucht Spectrum X später eigene Code-Signing-Zertifikate.

## Berechtigungen

ORION fragt Kamera, Mikrofon, Standort oder Bildschirm erst an, wenn die jeweilige Funktion benutzt wird. Nachrichten, Käufe, Buchungen und andere irreversible Schritte erfordern immer die letzte Bestätigung des Nutzers.

Android kann Hintergrund-Sprache nur über eine dauerhaft sichtbare Standby-Benachrichtigung bereitstellen. Lokale Befehle funktionieren dort ohne API-Aufruf. Komplexe Standby-Befehle werden sicher an die geöffnete ORION-App übergeben. Die APK ergänzt native Spracherkennung für Live-Gespräche sowie eine jedes Mal sichtbar bestätigte Bildschirmaufnahme. Online-KI läuft nach persönlicher Anmeldung nutzergebunden über Puter.js und wird niemals Spectrum X oder Baran berechnet. Nutzer erhalten ein kostenloses Kontingent; Anbieter-Limits oder selbst bestätigte Upgrades gelten nur für das jeweilige Nutzerkonto.

Im gemeinsamen Web-Interface stehen das neue Spectrum-X-Logo und Onboarding, 14 Persönlichkeitsmodi mit kontrollierter Nähe, 14 App-Sprachen, acht weibliche/männliche Neural-/Gerätestimmen, sichtbare Timer, Translator, File Studio, Game Lab mit Bug-Fix, verbessertes Bildstudio, Livestream-Player, Stream-Chat-Copilot, sichtbares ORION-Gehirn, Gerätezentrum, elf Radio-Sender inklusive PHONK sowie ein vollständiger JSON-Rohdatenexport bereit. Ein eigener API-Zugang wird getestet; Anbieter, Basis-URL und Modellversionen werden soweit möglich automatisch erkannt. Die Profile SuperSparsam, Smart Balance und Maximum passen Modellwahl, Antwortlänge und Kontext an. Das Gamer-/Streamer-Control-Center ergänzt Creator-Profil, Call-Länge, Performance-Modus und automatische Wiederherstellung. Der ORION Gaming Coach analysiert nur freiwillig geteilte sichtbare Bildschirmframes und gibt kurze sichtbare oder gesprochene taktische Calls; er verwendet keine versteckten Spieldaten und umgeht keinen Anti-Cheat-Schutz. Nutzer wählen zwischen persönlicher Anmeldung ohne API-Key und einer eigenen OpenAI-kompatiblen API. Ein eigener Nutzer-Key wird nie in GitHub oder Backups übernommen. Neural-Stimme, Gaming-Frames und Online-Spracherkennung laufen über das persönliche Nutzerkonto; die lokale Geräte-Stimme und das Radio verwenden keinen Betreiber-API-Key.
