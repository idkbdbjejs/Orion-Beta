-keepclassmembers class com.barys.orion.OrionBridge {
    @android.webkit.JavascriptInterface <methods>;
}
