plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.barys.orion"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.barys.orion"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "1.0.0-beta.7"
        buildConfigField("String", "ORION_URL", "\"https://orion-v1-beta.barysyt907.chatgpt.site\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {}
