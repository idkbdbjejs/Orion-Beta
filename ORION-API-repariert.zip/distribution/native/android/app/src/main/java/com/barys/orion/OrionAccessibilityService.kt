package com.barys.orion

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent

class OrionAccessibilityService : AccessibilityService() {
    companion object {
        var instance: OrionAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun insertText(text: String): Boolean {
        val node = findFocusedNode(rootInActiveWindow) ?: return false
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    fun globalAction(action: String): Boolean = when (action) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "scroll-down" -> performScroll(rootInActiveWindow, AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        "scroll-up" -> performScroll(rootInActiveWindow, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        else -> false
    }

    fun clickSafeAction(action: String): Boolean {
        if (action != "add-to-cart") return false
        val allowedLabels = setOf(
            "in den warenkorb",
            "zum warenkorb hinzufügen",
            "in den einkaufswagen",
            "add to cart",
            "add to basket",
        )
        val node = findNodeByAllowedLabel(rootInActiveWindow, allowedLabels) ?: return false
        return clickNodeOrParent(node)
    }

    private fun findFocusedNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isFocused && node.isEditable) return node
        for (index in 0 until node.childCount) {
            findFocusedNode(node.getChild(index))?.let { return it }
        }
        return null
    }

    private fun performScroll(node: AccessibilityNodeInfo?, action: Int): Boolean {
        if (node == null) return false
        if (node.isScrollable && node.performAction(action)) return true
        for (index in 0 until node.childCount) {
            if (performScroll(node.getChild(index), action)) return true
        }
        return false
    }

    private fun findNodeByAllowedLabel(node: AccessibilityNodeInfo?, allowed: Set<String>): AccessibilityNodeInfo? {
        if (node == null) return null
        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
        val description = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
        if (text in allowed || description in allowed) return node
        for (index in 0 until node.childCount) {
            findNodeByAllowedLabel(node.getChild(index), allowed)?.let { return it }
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return clickNodeOrParent(node.parent)
    }
}
