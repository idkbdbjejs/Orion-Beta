package com.barys.orion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class OrionStandbyService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "com.barys.orion.START_STANDBY"
        const val ACTION_STOP = "com.barys.orion.STOP_STANDBY"
        const val ACTION_UPDATE = "com.barys.orion.UPDATE_STANDBY"
        const val EXTRA_CONFIG = "orion_config"
        const val EXTRA_COMMAND = "orion_command"
        private const val CHANNEL_ID = "orion_standby"
        private const val NOTIFICATION_ID = 7101
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var preferredName = "Meister"
    private var wakeWord = "orion"
    private var speechLanguage = "de-DE"
    private var autoActions = true
    private var awaitingCommand = false
    private var active = false
    private var speaking = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        textToSpeech = TextToSpeech(this, this)
        recognizer = if (SpeechRecognizer.isRecognitionAvailable(this)) SpeechRecognizer.createSpeechRecognizer(this) else null
        recognizer?.setRecognitionListener(this)
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ORION:StandbyVoice")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopStandby()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> updateConfig(intent.getStringExtra(EXTRA_CONFIG))
            else -> {
                updateConfig(intent?.getStringExtra(EXTRA_CONFIG))
                active = true
                startForeground(NOTIFICATION_ID, notification("Aktiv · sage „${wakeWord.replaceFirstChar { it.uppercase() }}“"))
                if (wakeLock?.isHeld != true) wakeLock?.acquire(12 * 60 * 60 * 1000L)
                startListening(500)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        textToSpeech?.language = Locale.forLanguageTag(speechLanguage)
        textToSpeech?.setSpeechRate(1.04f)
        textToSpeech?.setPitch(0.94f)
        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false; startListening(250) }
            override fun onError(utteranceId: String?) { speaking = false; startListening(500) }
        })
    }

    private fun updateConfig(raw: String?) {
        if (raw.isNullOrBlank()) return
        runCatching {
            val json = JSONObject(raw)
            preferredName = json.optString("preferredName", "Meister").trim().ifEmpty { "Meister" }.take(40)
            wakeWord = json.optString("wakeWord", "Orion").trim().lowercase(Locale.GERMAN).ifEmpty { "orion" }.take(24)
            speechLanguage = json.optString("speechLanguage", "de-DE").takeIf { it.matches(Regex("^[a-zA-Z]{2,3}(-[a-zA-Z]{2,4})?$")) } ?: "de-DE"
            autoActions = json.optBoolean("autoActions", true)
            textToSpeech?.language = Locale.forLanguageTag(speechLanguage)
        }
    }

    private fun startListening(delay: Long) {
        if (!active || speaking) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (!active || speaking) return@postDelayed
            runCatching {
                recognizer?.cancel()
                recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLanguage)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                })
            }.onFailure { startListening(1200) }
        }, delay)
    }

    override fun onResults(results: Bundle?) {
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        handleTranscript(phrases.firstOrNull().orEmpty())
    }

    override fun onPartialResults(partialResults: Bundle?) = Unit

    private fun handleTranscript(raw: String) {
        val transcript = raw.trim()
        if (transcript.isEmpty()) return startListening(400)
        val lower = transcript.lowercase(Locale.GERMAN)
        val command = when {
            awaitingCommand -> transcript
            lower.contains(wakeWord) -> transcript.substringAfter(wakeWord, "").trim(' ', ',', '.', '!', '?')
            else -> return startListening(300)
        }
        if (command.isEmpty()) {
            awaitingCommand = true
            speak("Ja, $preferredName?")
            return
        }
        awaitingCommand = false
        execute(command)
    }

    private fun execute(command: String) {
        val lower = command.lowercase(Locale.GERMAN)
        when {
            lower.matches(Regex(".*(standby|zuhören).*(aus|stop|beenden).*")) -> {
                speak("Standby wird beendet, $preferredName.")
                handler.postDelayed({ stopStandby() }, 1300)
            }
            lower.contains("uhr") || lower.contains("wie spät") -> {
                val time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
                speak("Es ist $time Uhr, $preferredName.")
            }
            lower.startsWith("öffne youtube") -> openUrl("https://www.youtube.com", "YouTube")
            lower.startsWith("öffne spotify") -> openUrl("https://open.spotify.com", "Spotify")
            lower.startsWith("öffne whatsapp") -> openUrl("https://wa.me/", "WhatsApp")
            lower.startsWith("öffne gmail") -> openUrl("https://mail.google.com", "Gmail")
            lower.startsWith("öffne maps") || lower.startsWith("öffne navigation") -> openUrl("https://maps.google.com", "Google Maps")
            lower.startsWith("öffne amazon") -> openUrl("https://www.amazon.de", "Amazon")
            Regex("^(schreibe|tippe|füge)( bitte)? (hier |in das feld |in die app )?(.+)$").matches(lower) -> {
                if (!autoActions) return speak("Aktiviere zuerst Sichere Aktionen in ORION, $preferredName.")
                val content = Regex("^(schreibe|tippe|füge)( bitte)? (hier |in das feld |in die app )?", RegexOption.IGNORE_CASE).replace(command, "").trim()
                val inserted = content.isNotEmpty() && OrionAccessibilityService.instance?.insertText(content) == true
                speak(if (inserted) "Text eingesetzt. Absenden bleibt bei dir, $preferredName." else "Wähle zuerst ein Textfeld und aktiviere ORION Geräteaktionen, $preferredName.")
            }
            lower.contains("in den warenkorb") || lower.contains("zum warenkorb") -> {
                if (!autoActions) return speak("Aktiviere zuerst Sichere Aktionen in ORION, $preferredName.")
                val added = OrionAccessibilityService.instance?.clickSafeAction("add-to-cart") == true
                speak(if (added) "In den Warenkorb wurde ausgelöst. Kaufen und bezahlen bleiben bei dir, $preferredName." else "Keine eindeutige Warenkorb Schaltfläche gefunden, $preferredName.")
            }
            lower == "zurück" || lower.endsWith(" geh zurück") -> performDeviceAction("back", "Zurück")
            lower.contains("startbildschirm") || lower == "home" -> performDeviceAction("home", "Startbildschirm")
            lower.contains("letzte apps") || lower.contains("offene apps") -> performDeviceAction("recents", "Letzte Apps")
            lower.contains("benachrichtigungen") -> performDeviceAction("notifications", "Benachrichtigungen")
            lower.contains("scrolle") && lower.contains("unten") -> performDeviceAction("scroll-down", "Nach unten")
            lower.contains("scrolle") && lower.contains("oben") -> performDeviceAction("scroll-up", "Nach oben")
            lower.startsWith("bestelle ") || lower.startsWith("kaufe ") -> {
                val query = command.substringAfter(' ').trim()
                openUrl("https://www.google.com/search?tbm=shop&q=${Uri.encode(query)}", "Produktsuche")
            }
            lower.startsWith("öffne ") || lower.startsWith("starte ") -> {
                if (!autoActions) return speak("Aktiviere zuerst Sichere Aktionen in ORION, $preferredName.")
                val label = command.substringAfter(' ').trim()
                val opened = openInstalledApp(label)
                if (opened) {
                    speak("$label wird geöffnet, $preferredName.")
                } else {
                    val storeUrl = "https://play.google.com/store/search?q=${Uri.encode(label)}&c=apps"
                    openUrl(storeUrl, "$label im Play Store")
                }
            }
            else -> handOffToFreeCore(command)
        }
    }

    private fun performDeviceAction(action: String, label: String) {
        if (!autoActions) return speak("Aktiviere zuerst Sichere Aktionen in ORION, $preferredName.")
        val done = OrionAccessibilityService.instance?.globalAction(action) == true
        if (done) speak("$label ausgeführt, $preferredName.")
        else speak("ORION Geräteaktionen braucht noch die Bedienungshilfen Freigabe, $preferredName.")
    }

    private fun openInstalledApp(label: String): Boolean {
        val normalized = label.trim().lowercase(Locale.ROOT)
        val directIntent = when (normalized) {
            "kamera", "camera" -> Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            "einstellungen", "settings" -> Intent(Settings.ACTION_SETTINGS)
            "telefon", "phone" -> Intent(Intent.ACTION_DIAL)
            "kontakte", "contacts" -> Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people"))
            else -> null
        }
        if (directIntent != null) {
            directIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return runCatching { startActivity(directIntent); true }.getOrDefault(false)
        }
        val launcherQuery = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcherQuery, 0)
            .map { it to it.loadLabel(packageManager).toString() }
        val match = apps.firstOrNull { (_, name) -> name.lowercase(Locale.ROOT) == normalized }
            ?: apps.firstOrNull { (_, name) -> name.lowercase(Locale.ROOT).contains(normalized) }
            ?: return false
        val launch = packageManager.getLaunchIntentForPackage(match.first.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { startActivity(launch); true }.getOrDefault(false)
    }

    private fun handOffToFreeCore(command: String) {
        queueForApp(command)
        speak("Der Befehl ist bereit, $preferredName. Tippe auf die ORION Benachrichtigung. Die Online Antwort läuft dort ohne zentralen API Schlüssel und wird niemals Spectrum X berechnet.")
    }

    private fun openUrl(url: String, label: String) {
        if (!autoActions) return speak("Aktiviere zuerst Sichere Aktionen in ORION, $preferredName.")
        queueForApp("Öffne $label")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(intent) }
        speak("$label wird geöffnet, $preferredName.")
    }

    private fun queueForApp(command: String) {
        getSharedPreferences("orion_runtime", MODE_PRIVATE).edit().putString(EXTRA_COMMAND, command).apply()
        updateNotification("Befehl bereit · tippen zum Öffnen")
    }

    private fun speak(text: String) {
        recognizer?.cancel()
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        if (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) updateNotification(text.take(80))
        textToSpeech?.speak(text.take(1800), TextToSpeech.QUEUE_FLUSH, null, "orion-${System.currentTimeMillis()}")
    }

    private fun notification(status: String): android.app.Notification {
        val pendingCommand = getSharedPreferences("orion_runtime", MODE_PRIVATE).getString(EXTRA_COMMAND, null)
        val openIntent = Intent(this, MainActivity::class.java).apply {
            pendingCommand?.let { putExtra(EXTRA_COMMAND, it) }
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pending = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, OrionStandbyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return android.app.Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.orion_icon)
            .setContentTitle("ORION Standby")
            .setContentText(status)
            .setOngoing(true)
            .setContentIntent(pending)
            .addAction(android.R.drawable.ic_media_pause, "Beenden", stop)
            .build()
    }

    private fun updateNotification(status: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(status))
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "ORION Standby", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Sichtbarer Mikrofon- und Sprachdienst für ORION"
            setSound(null, null)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun stopStandby() {
        active = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        textToSpeech?.shutdown()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        super.onDestroy()
    }

    override fun onError(error: Int) { startListening(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 650) }
    override fun onReadyForSpeech(params: Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit
}
