package com.barys.orion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_SCREEN_CAPTURE = 712
    }

    private lateinit var webView: WebView
    private val trustedHost = Uri.parse(BuildConfig.ORION_URL).host
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var projectionManager: MediaProjectionManager
    private var pendingContinuousCapture = false
    private var pendingCaptureIntervalSeconds = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.orion_background)
        window.navigationBarColor = getColor(R.color.orion_background)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        webView = WebView(this).apply {
            setBackgroundColor(getColor(R.color.orion_background))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            addJavascriptInterface(OrionBridge(this@MainActivity), "ORION_ANDROID")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    if (request.origin.host == trustedHost) request.grant(request.resources) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.host == trustedHost) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    deliverPendingCommand(intent)
                }
            }
            loadUrl(BuildConfig.ORION_URL)
        }
        setContentView(webView)
        requestRuntimePermissions()
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        intent = newIntent
        deliverPendingCommand(newIntent)
    }

    private fun deliverPendingCommand(source: Intent?) {
        val command = source?.getStringExtra(OrionStandbyService.EXTRA_COMMAND)?.trim().orEmpty()
        if (command.isEmpty() || !::webView.isInitialized) return
        val encoded = JSONObject.quote(command)
        webView.evaluateJavascript(
            "window.dispatchEvent(new CustomEvent('orion-native-command',{detail:{text:$encoded}}));",
            null,
        )
        getSharedPreferences("orion_runtime", MODE_PRIVATE).edit().remove(OrionStandbyService.EXTRA_COMMAND).apply()
        source?.removeExtra(OrionStandbyService.EXTRA_COMMAND)
    }

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 710)
    }

    fun startSpeechRecognition(language: String): Boolean {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 711) }
            return false
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return false
        runOnUiThread {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onResults(results: Bundle?) {
                            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                            if (text.isNotEmpty()) dispatchEvent("orion-native-speech-result", JSONObject().put("text", text))
                            else dispatchEvent("orion-native-speech-error", JSONObject().put("error", "Kein Sprachtext erkannt"))
                        }

                        override fun onError(error: Int) {
                            val reason = when (error) {
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofonfreigabe fehlt"
                                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Sprachnetzwerk nicht erreichbar"
                                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Keine Sprache erkannt"
                                else -> "Spracherkennung Fehler $error"
                            }
                            dispatchEvent("orion-native-speech-error", JSONObject().put("error", reason))
                        }

                        override fun onReadyForSpeech(params: Bundle?) = Unit
                        override fun onBeginningOfSpeech() = Unit
                        override fun onRmsChanged(rmsdB: Float) = Unit
                        override fun onBufferReceived(buffer: ByteArray?) = Unit
                        override fun onEndOfSpeech() = Unit
                        override fun onPartialResults(partialResults: Bundle?) = Unit
                        override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    })
                }
            }
            speechRecognizer?.cancel()
            speechRecognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.takeIf { it.matches(Regex("^[a-zA-Z]{2,3}(-[a-zA-Z]{2,4})?$")) } ?: "de-DE")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
        }
        return true
    }

    fun stopSpeechRecognition() {
        runOnUiThread { speechRecognizer?.cancel() }
    }

    fun requestScreenCapture(): Boolean {
        pendingContinuousCapture = false
        runOnUiThread { startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE) }
        return true
    }

    fun requestGamingCapture(intervalSeconds: Int): Boolean {
        pendingContinuousCapture = true
        pendingCaptureIntervalSeconds = intervalSeconds.coerceIn(8, 30)
        runOnUiThread { startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE) }
        return true
    }

    fun stopGamingCapture() {
        startService(Intent(this, OrionScreenCaptureService::class.java).setAction(OrionScreenCaptureService.ACTION_STOP))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SCREEN_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            dispatchEvent("orion-native-screen-capture", JSONObject().put("error", "Bildschirmfreigabe abgebrochen").put("continuous", pendingContinuousCapture))
            pendingContinuousCapture = false
            return
        }
        val continuous = pendingContinuousCapture
        val intervalSeconds = pendingCaptureIntervalSeconds
        pendingContinuousCapture = false
        OrionScreenCaptureService.captureListener = { dataUrl, error ->
            val detail = JSONObject().put("continuous", continuous)
            if (dataUrl != null) detail.put("dataUrl", dataUrl)
            if (error != null) detail.put("error", error)
            dispatchEvent("orion-native-screen-capture", detail)
        }
        val service = Intent(this, OrionScreenCaptureService::class.java)
            .putExtra(OrionScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(OrionScreenCaptureService.EXTRA_RESULT_DATA, data)
            .putExtra(OrionScreenCaptureService.EXTRA_CONTINUOUS, continuous)
            .putExtra(OrionScreenCaptureService.EXTRA_INTERVAL_SECONDS, intervalSeconds)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
    }

    private fun dispatchEvent(name: String, detail: JSONObject) {
        if (!::webView.isInitialized) return
        runOnUiThread {
            webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent(${JSONObject.quote(name)},{detail:${detail}}));",
                null,
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}
