package com.barys.orion

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.JavascriptInterface
import java.util.Locale

class OrionBridge(private val activity: MainActivity) {
    @JavascriptInterface
    fun startStandby(config: String) {
        val intent = Intent(activity, OrionStandbyService::class.java)
            .setAction(OrionStandbyService.ACTION_START)
            .putExtra(OrionStandbyService.EXTRA_CONFIG, config)
        if (Build.VERSION.SDK_INT >= 26) activity.startForegroundService(intent) else activity.startService(intent)
    }

    @JavascriptInterface
    fun stopStandby() {
        activity.startService(Intent(activity, OrionStandbyService::class.java).setAction(OrionStandbyService.ACTION_STOP))
    }

    @JavascriptInterface
    fun updateConfig(config: String) {
        activity.startService(
            Intent(activity, OrionStandbyService::class.java)
                .setAction(OrionStandbyService.ACTION_UPDATE)
                .putExtra(OrionStandbyService.EXTRA_CONFIG, config),
        )
    }

    @JavascriptInterface
    fun startSpeechRecognition(language: String): Boolean = activity.startSpeechRecognition(language)

    @JavascriptInterface
    fun stopSpeechRecognition() = activity.stopSpeechRecognition()

    @JavascriptInterface
    fun captureScreen(): Boolean = activity.requestScreenCapture()

    @JavascriptInterface
    fun startGamingCapture(intervalSeconds: Int): Boolean = activity.requestGamingCapture(intervalSeconds)

    @JavascriptInterface
    fun stopGamingCapture() = activity.stopGamingCapture()

    @JavascriptInterface
    fun insertText(text: String): Boolean = OrionAccessibilityService.instance?.insertText(text) == true

    @JavascriptInterface
    fun openAccessibilitySettings() {
        activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    @JavascriptInterface
    fun openExternal(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        if (uri.scheme !in setOf("https", "http", "mailto", "tel", "geo")) return false
        return runCatching {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        }.getOrDefault(false)
    }

    @JavascriptInterface
    fun openApp(name: String): Boolean {
        val normalized = name.trim().lowercase(Locale.ROOT)
        if (normalized.isEmpty()) return false
        val directIntent = when (normalized) {
            "camera", "kamera" -> Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            "settings", "einstellungen" -> Intent(Settings.ACTION_SETTINGS)
            "phone", "telefon" -> Intent(Intent.ACTION_DIAL)
            "contacts", "kontakte" -> Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people"))
            else -> null
        }
        if (directIntent != null) {
            return runCatching { activity.startActivity(directIntent); true }.getOrDefault(false)
        }

        val aliases = mapOf(
            "youtube" to "com.google.android.youtube",
            "spotify" to "com.spotify.music",
            "whatsapp" to "com.whatsapp",
            "gmail" to "com.google.android.gm",
            "mail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "amazon" to "com.amazon.mShop.android.shopping",
            "netflix" to "com.netflix.mediaclient",
            "notes" to "com.google.android.keep",
            "notizen" to "com.google.android.keep",
            "calendar" to "com.google.android.calendar",
            "kalender" to "com.google.android.calendar",
            "calculator" to "com.google.android.calculator",
            "rechner" to "com.google.android.calculator",
            "browser" to "com.android.chrome",
            "chrome" to "com.android.chrome",
        )
        aliases[normalized]?.let { packageName ->
            activity.packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
                return runCatching { activity.startActivity(launch); true }.getOrDefault(false)
            }
        }

        val launcherQuery = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = activity.packageManager.queryIntentActivities(launcherQuery, 0)
            .map { it to it.loadLabel(activity.packageManager).toString() }
            .firstOrNull { (_, label) -> label.lowercase(Locale.ROOT) == normalized }
            ?: activity.packageManager.queryIntentActivities(launcherQuery, 0)
                .map { it to it.loadLabel(activity.packageManager).toString() }
                .firstOrNull { (_, label) -> label.lowercase(Locale.ROOT).contains(normalized) }
            ?: return false
        val launch = activity.packageManager.getLaunchIntentForPackage(match.first.activityInfo.packageName) ?: return false
        return runCatching { activity.startActivity(launch); true }.getOrDefault(false)
    }

    @JavascriptInterface
    fun globalAction(action: String): Boolean = OrionAccessibilityService.instance?.globalAction(action) == true

    @JavascriptInterface
    fun clickSafeAction(action: String): Boolean = OrionAccessibilityService.instance?.clickSafeAction(action) == true
}
