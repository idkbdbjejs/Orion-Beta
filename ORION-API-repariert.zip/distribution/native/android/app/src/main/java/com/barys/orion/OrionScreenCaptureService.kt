package com.barys.orion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.Base64
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class OrionScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "orion_projection_result_code"
        const val EXTRA_RESULT_DATA = "orion_projection_result_data"
        const val EXTRA_CONTINUOUS = "orion_projection_continuous"
        const val EXTRA_INTERVAL_SECONDS = "orion_projection_interval_seconds"
        const val ACTION_STOP = "com.barys.orion.STOP_SCREEN_CAPTURE"
        private const val CHANNEL_ID = "orion_screen_capture"
        private const val NOTIFICATION_ID = 7102

        @Volatile
        var captureListener: ((String?, String?) -> Unit)? = null
    }

    private val finished = AtomicBoolean(false)
    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var continuousCapture = false
    private var intervalMs = 12_000L
    private var lastCaptureAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        workerThread = HandlerThread("orion-screen-capture").apply { start() }
        worker = Handler(workerThread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finishCapture(null, if (continuousCapture) "Gaming Coach beendet" else "Bildschirmfreigabe beendet")
            return START_NOT_STICKY
        }
        continuousCapture = intent?.getBooleanExtra(EXTRA_CONTINUOUS, false) == true
        intervalMs = (intent?.getIntExtra(EXTRA_INTERVAL_SECONDS, 12) ?: 12).coerceIn(8, 30) * 1000L
        val stopIntent = Intent(this, OrionScreenCaptureService::class.java).setAction(ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(this, 7102, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = android.app.Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.orion_icon)
            .setContentTitle(if (continuousCapture) "ORION Gaming Coach aktiv" else "ORION Bildschirmaufnahme")
            .setContentText(if (continuousCapture) "Der freigegebene Bildschirm wird sichtbar analysiert." else "Ein Bildschirmbild wird nach deiner Freigabe erstellt.")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOPP", stopPendingIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, android.app.Activity.RESULT_CANCELED) ?: android.app.Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
            finishCapture(null, "Ungültige Bildschirmfreigabe")
            return START_NOT_STICKY
        }
        runCatching { beginCapture(resultCode, resultData) }
            .onFailure { finishCapture(null, "Bildschirmaufnahme konnte nicht gestartet werden") }
        return START_NOT_STICKY
    }

    private fun beginCapture(resultCode: Int, resultData: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = projectionManager.getMediaProjection(resultCode, resultData)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                finishCapture(null, "Bildschirmfreigabe wurde beendet")
            }
        }, worker)

        val density = resources.displayMetrics.densityDpi
        val (width, height) = if (Build.VERSION.SDK_INT >= 30) {
            val bounds = (getSystemService(WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            resources.displayMetrics.widthPixels to resources.displayMetrics.heightPixels
        }
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val now = SystemClock.elapsedRealtime()
            if (continuousCapture && lastCaptureAt > 0 && now - lastCaptureAt < intervalMs) {
                image.close()
                return@setOnImageAvailableListener
            }
            lastCaptureAt = now
            try {
                val plane = image.planes.first()
                val rowPadding = plane.rowStride - plane.pixelStride * width
                val padded = Bitmap.createBitmap(width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
                val outputBitmap = if (cropped.width > 1024) {
                    Bitmap.createScaledBitmap(cropped, 1024, (cropped.height * (1024.0 / cropped.width)).toInt().coerceAtLeast(1), true)
                } else {
                    cropped
                }
                val bytes = ByteArrayOutputStream().use { output ->
                    outputBitmap.compress(Bitmap.CompressFormat.JPEG, 70, output)
                    output.toByteArray()
                }
                padded.recycle()
                if (outputBitmap !== cropped) outputBitmap.recycle()
                cropped.recycle()
                val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                if (continuousCapture) captureListener?.invoke("data:image/jpeg;base64,$encoded", null)
                else finishCapture("data:image/jpeg;base64,$encoded", null)
            } catch (_: Throwable) {
                finishCapture(null, "Bildschirmbild konnte nicht verarbeitet werden")
            } finally {
                image.close()
            }
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "ORION-Screen-Capture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            worker,
        )
        if (!continuousCapture) worker.postDelayed({ finishCapture(null, "Zeitüberschreitung bei der Bildschirmaufnahme") }, 10_000)
    }

    private fun finishCapture(dataUrl: String?, error: String?) {
        if (!finished.compareAndSet(false, true)) return
        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.close() }
        runCatching { projection?.stop() }
        captureListener?.invoke(dataUrl, error)
        captureListener = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "ORION Bildschirmaufnahme", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Sichtbarer Dienst für eine vom Nutzer bestätigte Bildschirmaufnahme"
            setSound(null, null)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        if (!finished.get()) finishCapture(null, "Bildschirmaufnahme wurde beendet")
        workerThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
