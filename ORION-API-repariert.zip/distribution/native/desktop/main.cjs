/* eslint-disable @typescript-eslint/no-require-imports */
const { app, BrowserWindow, clipboard, ipcMain, shell, session } = require("electron");
const { execFile } = require("child_process");
const path = require("path");

const ORION_URL = "https://orion-v1-beta.barysyt907.chatgpt.site";
const ORION_ORIGIN = new URL(ORION_URL).origin;
let mainWindow = null;

function safeExternalUrl(raw) {
  try {
    const url = new URL(raw);
    return ["https:", "http:", "mailto:", "tel:", "geo:"].includes(url.protocol) ? url.toString() : null;
  } catch {
    return null;
  }
}

function runPasteCommand() {
  return new Promise((resolve) => {
    const finish = (error) => resolve(!error);
    if (process.platform === "win32") {
      execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^v')"], finish);
      return;
    }
    if (process.platform === "darwin") {
      execFile("osascript", ["-e", "tell application \"System Events\" to keystroke \"v\" using command down"], finish);
      return;
    }
    execFile("xdotool", ["key", "ctrl+v"], finish);
  });
}

function runDesktopApp(name) {
  const aliases = {
    notes: "notes", notizen: "notes", kalender: "calendar", calendar: "calendar",
    mail: "mail", email: "mail", rechner: "calculator", taschenrechner: "calculator", calculator: "calculator",
    einstellungen: "settings", settings: "settings", kamera: "camera", camera: "camera",
    kontakte: "contacts", contacts: "contacts", browser: "browser", chrome: "browser", safari: "browser", edge: "browser", firefox: "browser"
  };
  const key = aliases[String(name || "").trim().toLowerCase()];
  if (!key) return Promise.resolve(false);
  if (key === "browser") return shell.openExternal("https://www.google.com").then(() => true).catch(() => false);
  return new Promise((resolve) => {
    let command;
    let args;
    if (process.platform === "win32") {
      const windows = {
        notes: ["notepad.exe", []], calendar: ["cmd.exe", ["/c", "start", "", "outlookcal:"]],
        mail: ["cmd.exe", ["/c", "start", "", "mailto:"]], calculator: ["calc.exe", []],
        settings: ["cmd.exe", ["/c", "start", "", "ms-settings:"]], camera: ["cmd.exe", ["/c", "start", "", "microsoft.windows.camera:"]],
        contacts: ["cmd.exe", ["/c", "start", "", "ms-people:"]]
      };
      [command, args] = windows[key];
    } else if (process.platform === "darwin") {
      const mac = { notes: "Notes", calendar: "Calendar", mail: "Mail", calculator: "Calculator", settings: "System Settings", camera: "Photo Booth", contacts: "Contacts" };
      command = "open";
      args = ["-a", mac[key]];
    } else {
      const linux = { notes: "gnome-text-editor", calendar: "gnome-calendar", mail: "xdg-email", calculator: "gnome-calculator", settings: "gnome-control-center", camera: "cheese", contacts: "gnome-contacts" };
      command = linux[key];
      args = [];
    }
    execFile(command, args, (error) => resolve(!error));
  });
}

ipcMain.handle("orion:open-external", async (_event, raw) => {
  const url = safeExternalUrl(String(raw || ""));
  if (!url) return false;
  await shell.openExternal(url);
  return true;
});

ipcMain.handle("orion:open-app", (_event, name) => runDesktopApp(name));

ipcMain.handle("orion:copy-text", (_event, value) => {
  clipboard.writeText(String(value || "").slice(0, 20000));
  return true;
});

ipcMain.handle("orion:type-text", async (_event, value) => {
  const text = String(value || "").slice(0, 20000);
  if (!text) return false;
  clipboard.writeText(text);
  if (process.platform === "darwin") app.hide();
  else mainWindow?.minimize();
  await new Promise((resolve) => setTimeout(resolve, 650));
  return runPasteCommand();
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 620,
    backgroundColor: "#02080b",
    title: "ORION V1 Beta",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow = win;

  win.webContents.setWindowOpenHandler(({ url }) => {
    const target = new URL(url);
    if (target.origin === ORION_ORIGIN) return { action: "allow" };
    void shell.openExternal(url);
    return { action: "deny" };
  });

  win.webContents.on("will-navigate", (event, url) => {
    if (new URL(url).origin === ORION_ORIGIN) return;
    event.preventDefault();
    void shell.openExternal(url);
  });

  void win.loadURL(ORION_URL);
  win.on("closed", () => { if (mainWindow === win) mainWindow = null; });
}

app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    callback(["media", "display-capture", "geolocation", "notifications"].includes(permission));
  });
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
