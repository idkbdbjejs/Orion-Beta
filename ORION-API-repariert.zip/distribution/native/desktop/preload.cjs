/* eslint-disable @typescript-eslint/no-require-imports */
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("ORION_NATIVE", {
  platform: process.platform,
  desktop: true,
  version: "1.0.0-beta.6",
  openExternal: (url) => ipcRenderer.invoke("orion:open-external", url),
  openApp: (name) => ipcRenderer.invoke("orion:open-app", name),
  typeText: (text) => ipcRenderer.invoke("orion:type-text", text),
  copyText: (text) => ipcRenderer.invoke("orion:copy-text", text)
});
