# ORION Zero-Owner-Cost-Regel

Diese öffentliche ORION-Version ist so gebaut, dass Nutzung durch andere Personen keine KI- oder API-Rechnung für Spectrum X, Baran oder die Betreiber des GitHub-Repositorys erzeugen kann.

## Technische Regeln

1. Im Quellcode, in der Web-App und in der APK gibt es keinen gemeinsamen OpenAI- oder Entwickler-API-Schlüssel.
2. ORION besitzt keinen serverseitigen KI-Endpunkt, der öffentliche Aufrufe auf ein Betreiberkonto weiterberechnet.
3. Online-KI wird standardmäßig über Puter.js ausgeführt. Jeder Aufruf ist an das Puter-Konto des jeweiligen Nutzers gebunden.
4. Alternativ kann der Nutzer seine eigene OpenAI-kompatible API-Adresse und seinen eigenen Key eintragen. Dieser Key wird nur für direkte Anfragen vom Nutzergerät an diese Adresse verwendet, nie in GitHub oder ein Backup exportiert und bei ausgeschaltetem „merken“ nicht dauerhaft gespeichert.
5. Ohne persönliche Puter-Anmeldung oder vollständig eingerichtete eigene API startet ORION keinen Online-KI-Aufruf. Es gibt keinen anonymen Fallback auf ein Betreiberkonto.
6. Puter stellt Nutzern ein Kontingent bereit. Wird es überschritten, entscheidet Puter gegenüber diesem Nutzer über Limit oder ein von ihm selbst zu bestätigendes Upgrade. Bei eigener API gelten Tarif und Limits dieses Nutzers. Spectrum X wird in beiden Fällen nicht belastet.
7. ORION fragt keine Zahlungsdaten ab und speichert keine Zahlungsdaten.
8. Lokale Funktionen wie Einstellungen, Gedächtnis, Timer, Datei-Export, gespeicherte Chats, Kurzbefehle, Uhrzeit und unterstützte Geräteaktionen benötigen keine KI-Abrechnung.
9. Der Gaming Coach sendet nur nach ausdrücklicher Bildschirmfreigabe einzelne Frames im gewählten Abstand. Jeder Frame wird ausschließlich über den Nutzerzugang verarbeitet; bei eigener API kann dadurch eine Rechnung beim jeweiligen Nutzeranbieter entstehen, niemals beim ORION-Betreiber.
10. Bildgenerierung, automatische Gedächtnis-Erkennung und Stream-Antwortentwürfe verwenden ebenfalls ausschließlich den vom Nutzer gewählten persönlichen Zugang. Twitch-Chat-Lesen selbst braucht keinen ORION-Betreiber-Key; ORION versendet keine Chat-Nachricht automatisch.
11. Der SuperSparsam-Modus reduziert Antwortlänge, Kontext und automatische Lernaufrufe. Er kann Nutzung stark verringern, garantiert aber keinen kostenlosen Tarif beim persönlichen API-Anbieter.
12. ORION erkennt keine angebliche „Key-Stärke“. Es liest – soweit der Anbieter dies erlaubt – den Modellkatalog und wählt ein für das Sparprofil geeignetes Chat-Modell. Tarife, Guthaben und Abrechnung bleiben beim jeweiligen Anbieter und Key-Inhaber.

## Was „kostenlos“ hier genau bedeutet

- Für Spectrum X / Baran: keine nutzungsabhängigen KI- oder API-Kosten – unabhängig von der Nutzerzahl.
- Für Nutzer: Nutzung innerhalb des persönlichen Puter-Freikontingents ist kostenlos. Darüber hinaus kann der externe Anbieter begrenzen oder ein eigenes Upgrade anbieten.
- Ohne externen Anbieter können leistungsfähige Cloud-KI, Live-Websuche, Bildgenerierung und unbegrenzte Sprachantworten nicht seriös für beliebig viele Nutzer kostenlos garantiert werden, weil dafür Rechenleistung benötigt wird.

## Sicherheitsprüfung vor jeder Veröffentlichung

Vor einem öffentlichen Release muss die Suche nach typischen Geheimnissen leer bleiben, insbesondere nach `sk-`, `OPENAI_API_KEY`, `Authorization: Bearer` und privaten Provider-Schlüsseln. Falls später ein zentraler Backend-Dienst ergänzt wird, darf er nicht ohne ein ausdrücklich festgelegtes Budget, harte Limits und Missbrauchsschutz veröffentlicht werden.
