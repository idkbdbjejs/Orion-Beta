# ORION V1 Beta

**ORION – dein Leben, dein Assistent, deine Zukunft.**

ORION ist ein persönlicher KI-Assistent von Spectrum X für Web, Android, Windows, macOS und Linux. Das Projekt verbindet Chat, Sprache, Vision, lokales Gedächtnis, eigene Befehle und freigegebene Geräteaktionen in einer Oberfläche.

## Was bereits funktioniert

- KI-Chat ohne notwendiges ChatGPT-Abo und ohne zentralen ORION-API-Schlüssel
- wahlweise persönliche Puter-Anmeldung ohne API-Key oder eine eigene OpenAI-kompatible API; keine gemeinsame Betreiberabrechnung
- neu gestaltetes Spectrum-X-Onboarding mit Anrede, App-Sprache, ORION-Geschlecht, Persönlichkeit, Aktivierungswort und direkter Stimmprobe
- eigene Anrede, zum Beispiel „Meister“, sowie frei wählbares Aktivierungswort
- sichtbarer Live-Gesprächsmodus im Anruf-Stil mit automatischem Weiterhören; Firefox nutzt dafür kurze Mikrofon-Aufnahmen mit nutzergebundener Sprache-zu-Text-Erkennung
- 14 Persönlichkeitsmodi, Stärke-/Nähe-/Humor-/Förmlichkeitsregler, 14 App-Sprachen und acht professionelle weibliche/männliche Stimmen
- sichtbares ORION Radio mit elf Sendern inklusive PHONK, Song-Metadaten und zuverlässigem Stoppen
- verbessertes Bildstudio mit Modell-, Qualitäts- und Formatwahl sowie direktem Bild-Download
- API-Anbieter-Erkennung, Verbindungstest und vollständiger Modellkatalog für den eigenen Nutzer-Key
- automatische API-Optimierung: ORION erkennt Anbieter, Basis-URL und verfügbare Modellversionen und wählt passend zu **SuperSparsam**, **Smart Balance** oder **Maximum**
- neues Spectrum-X-App-Logo, separates Gamer-Icon und direkter SVG-/PNG-Download aus den Einstellungen
- sichtbares ORION-Gehirn mit getrennten Zählern für Chat, Erinnerungen, Befehle, Missionen, Timer und Stream-Chat
- sichtbare frei einstellbare Timer mit Alarm sowie Sprachbefehle wie „Timer 5 Sekunden“
- ORION Translator mit kompaktem Offline-Wörterbuch und freier Online-Übersetzung über den Nutzerzugang
- File Studio für TXT, Markdown, HTML, Word-kompatibles DOC und lokal erzeugte PDFs
- Game Lab mit Bot-Schwierigkeitsgrad, isolierter Vorschau, HTML-Download und eigenem Bug-Fix-Feld
- ORION Gaming Coach mit freiwilliger Bildschirmfreigabe, taktischen Kurz-Calls, wählbarem Analyseabstand, Sprach-Calls, Overlay und lokalem Call-Verlauf
- Gamer-/Streamer-Control-Center mit Creator-Profil, Rollen, Call-Länge, Performance-Modus, Streamer-Modus und automatischer Verbindungsreparatur
- Livestream-Player für YouTube/Twitch sowie externe Fallbacks für Plattformen, die Einbettung sperren
- Stream-Chat-Copilot: liest öffentlichen Twitch-Chat nach aktiver Verbindung, filtert Duplikate und erzeugt nicht wiederholende Antwortentwürfe; YouTube/TikTok/X lassen sich manuell importieren
- Gerätezentrum mit freigegebenen Modell-, Bildschirm-, Akku-, Netzwerk-, CPU- und Speicherwerten
- `*ICH Sicherheitszentrale` und `*ICH Geräte-Aktionsprotokoll`
- sichtbare Chat-leeren-Funktion, „Alles speichern“-Schaltfläche und vollständiger Rohdaten-Export für Chat, Gedächtnis, Befehle, Missionen, Stream-Chat und Einstellungen
- kontrollierte Beziehungsintensität von professionell bis liebevoll; die höchste Stufe bleibt bewusst nicht besitzergreifend oder abhängig
- native Android-APK mit sichtbarem Mikrofon-Standbydienst
- PC-Bildschirmfreigabe sowie bestätigte Android-Bildschirmaufnahme für ORION Vision
- lokale Standby-Befehle ohne API-Aufruf; komplexe Fragen werden sicher an den nutzergebundenen Online-Kern übergeben
- lokales Gedächtnis, eigene Kurzbefehle sowie Import und Export
- Kamera-, Bild- und Bildschirmfreigabe
- Öffnen von Webseiten, Navigation, Medien, Mail- und Nachrichtenentwürfen
- optionaler Android-Bedienungshilfedienst zum Einsetzen von Text in das aktive Feld
- PWA-Installation sowie Installer-Projekte für Android und Desktop

## Sicherheitsgrenzen

ORION fragt Mikrofon, Kamera, Bildschirm und Android-Bedienungshilfe sichtbar an. Der Standbydienst läuft als Android-Vordergrunddienst mit dauerhafter Systembenachrichtigung. Nachrichten absenden, Bestellungen, Zahlungen, Buchungen, Löschungen und andere irreversible Aktionen benötigen eine letzte Bestätigung.

Der Gaming Coach analysiert nur einzelne sichtbare Frames aus einer ausdrücklich freigegebenen Bildschirmquelle. Er liest keine versteckten Spieldaten oder Speicherwerte, umgeht keinen Anti-Cheat-Schutz und steuert das Spiel nicht. Jeder Analyse-Frame verwendet ausschließlich den vom Nutzer gewählten Puter-Zugang oder dessen eigene API. Je nach Browser und Betriebssystem können Hintergrund-Timer, Audio oder Benachrichtigungen gedrosselt werden.

Bildschirmfreigaben können von Browsern und Betriebssystemen nicht heimlich oder unbegrenzt neu gestartet werden. ORION zeigt deshalb den Verbindungsstatus sichtbar an, bereinigt unterbrochene App-Verbindungen sicher und hält den Bildschirm während einer aktiven Sitzung auf unterstützten Geräten optional wach. Eine neue Freigabe bleibt immer eine sichtbare Entscheidung des Nutzers.

ORION enthält weder im Quellcode noch in der Android-App einen gemeinsamen Entwickler- oder OpenAI-API-Schlüssel. Dadurch können öffentliche Nutzer keine API-Kosten auf dem Konto von Spectrum X oder Baran verursachen.

## Zero-Owner-Cost-Modell

Ein ChatGPT Plus-, Pro- oder Business-Abo ist für ORION nicht erforderlich. Standardmäßig läuft Online-KI über Puter.js im User-Pays-Modell: Jeder Nutzer meldet sich mit seinem eigenen Puter-Konto an und verwendet ausschließlich dessen Kontingent. Alternativ kann ein Nutzer bewusst seine eigene OpenAI-kompatible API-Adresse und seinen eigenen Key eintragen. Dieser Key wird nie in GitHub oder ein Backup geschrieben; optionales lokales Merken ist ausgeschaltet. Kosten oder Limits gehören ausschließlich zum gewählten Nutzerzugang und niemals Spectrum X oder Baran – auch nicht bei sehr vielen Nutzern.

Lokale Befehle, Einstellungen, Gedächtnis, gespeicherte Unterhaltungen und unterstützte Geräteaktionen bleiben ohne KI-Abrechnung nutzbar. Die vollständigen Regeln stehen in [COST_MODEL.md](COST_MODEL.md).

Ein API-Key selbst besitzt keine messbare „Stärke“. ORION fragt stattdessen den freigegebenen Modellkatalog des Anbieters ab, bewertet geeignete Chat-Modelle und passt Antwortlänge, Kontext und Lernfunktionen an das gewählte Sparprofil an. Bei Ratenlimits und vorübergehenden Serverfehlern wird einmal kontrolliert erneut versucht.

## Gerätesteuerung

- **Android-APK:** Öffnet installierte Apps nach ihrem sichtbaren Namen, öffnet Webseiten, setzt Text in das aktive Feld ein, führt Zurück/Home/Letzte Apps/Benachrichtigungen/Scrollen aus und kann ausschließlich eine eindeutig beschriftete „In den Warenkorb“-Schaltfläche anklicken. Dafür muss der Nutzer einmalig „ORION Geräteaktionen“ in den Android-Bedienungshilfen aktivieren. Der Gaming Coach kann nach einer sichtbaren Android-MediaProjection-Freigabe periodische Bildschirmframes verarbeiten; währenddessen bleibt eine Vordergrund-Benachrichtigung mit Stopp-Taste aktiv.
- **Windows/macOS/Linux-App:** Öffnet unterstützte System-Apps und Webseiten, kopiert Text und kann ihn nach Minimieren von ORION in die vorher aktive App einsetzen. macOS verlangt dafür Bedienungshilfen-Zugriff; Linux benötigt `xdotool` für automatisches Einfügen.
- **Web/PWA:** Kann Webseiten und Deep Links öffnen, Inhalte vorbereiten, in die Zwischenablage kopieren sowie freigegebene Kamera- und Bildschirmquellen verwenden. Browser dürfen aus Sicherheitsgründen nicht beliebige andere Apps steuern.
- **iPhone/iPad:** Unterstützt Live-Sprache innerhalb der App, Deep Links, Entwürfe und den Teilen-Dialog. iOS erlaubt Drittanbieter-Apps keinen allgemeinen Bedienungshilfen-Zugriff auf andere Apps; vollständige systemweite Fremdsteuerung ist dort technisch nicht freigegeben.

Absenden, „Jetzt kaufen“, Checkout und Bezahlen sind bewusst nicht automatisiert. Ein klarer Sprachbefehl kann Suche, Auswahlvorbereitung und – auf Android – „In den Warenkorb“ auslösen; die endgültige kostenpflichtige Bestätigung bleibt beim Nutzer.

## Projektstruktur

- `app/` – ORION-Weboberfläche
- `lib/` – ORION-Persönlichkeit und Modusregeln
- `public/` – PWA-Dateien und Markenassets
- `distribution/native/android/` – native Android-App mit Standbydienst
- `distribution/native/mobile/` – Capacitor-Projekt für mobile WebView-Builds
- `distribution/native/desktop/` – Electron-Installer für Windows, macOS und Linux
- `.github/workflows/` – öffentliche Installer-Builds

## Android-APK über GitHub bauen

1. Öffne im Repository den Bereich **Actions**.
2. Wähle **ORION Installer bauen**.
3. Klicke auf **Run workflow**.
4. Lade nach Abschluss das Artefakt **ORION-Android-APK** herunter.
5. Entpacke die ZIP-Datei und installiere `ORION-V1-Beta.apk`.

Android verlangt einmalig die Erlaubnis, eine APK aus dieser Quelle zu installieren. Für eine Veröffentlichung im Play Store muss später ein signierter Release-Build erstellt und die Verwendung von Mikrofon- und Bedienungshilfefunktionen vollständig erklärt werden.

## Lokale Web-Entwicklung

Voraussetzung ist Node.js 22 oder neuer.

```bash
npm ci
npm run dev
```

## Native Android-Entwicklung

Das Android-Projekt liegt unter `distribution/native/android`. Es verwendet Java 17, Android SDK 35 und Gradle.

## Status

ORION V1 befindet sich in der Beta. Standby-Spracherkennung hängt zusätzlich vom Android-Gerät, dem Sprachdienst und den Energiespareinstellungen ab. Komplexe Online-Antworten brauchen eine Internetverbindung und können den Freigrenzen des nutzergebundenen Anbieters unterliegen. iOS erlaubt keinen frei laufenden dauerhaften Mikrofon-Hintergrunddienst wie Android; dort ist der Sprachmodus innerhalb der App vorgesehen.

## Urheber

Spectrum X · Baran / Barys

Quellcode öffentlich einsehbar. Alle Rechte vorbehalten; siehe [LICENSE](LICENSE).
