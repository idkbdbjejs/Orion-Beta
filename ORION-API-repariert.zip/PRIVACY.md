# ORION Datenschutzübersicht

ORION speichert Chatverlauf, Einstellungen, eigene Befehle und persönliche Erinnerungen standardmäßig lokal auf dem jeweiligen Gerät. Nutzer können diese Daten in der App löschen sowie als Backup exportieren.

## Berechtigungen

- Mikrofon: nur für Sprachbefehle und den ausdrücklich aktivierten Android-Standbydienst
- Kamera und Bildschirm: nur nach Auswahl durch den Nutzer
- Bedienungshilfe unter Android: optional, um Text in das aktuell fokussierte Feld einzusetzen
- Benachrichtigungen: Status und Beenden des sichtbaren Standbydienstes

## KI-Anbieter

Anfragen können je nach gewählter Funktion über Puter.js an externe KI-Anbieter übertragen werden. Vor Online-KI muss sich jeder Nutzer mit seinem eigenen Puter-Konto anmelden. ORION fordert, speichert oder verteilt keinen OpenAI-API-Schlüssel, keine Zahlungsdaten und keinen gemeinsamen Entwickler-Schlüssel, über den öffentliche Nutzung abgerechnet werden könnte.

Puter stellt jedem Nutzer ein eigenes kostenloses Kontingent bereit und kann bei dessen Überschreitung nur diesem Nutzer ein selbst zu bestätigendes Upgrade anbieten. Eine mögliche Abrechnung findet ausschließlich zwischen dem jeweiligen Nutzer und Puter statt; sie läuft nicht über Spectrum X oder Baran.

## Geschützte Aktionen

Nachrichtenversand, Bestellungen, Zahlungen, Buchungen, Anmeldungen, Löschungen und andere irreversible Aktionen werden nicht ohne eine letzte Bestätigung ausgeführt.

Vor einer Veröffentlichung in App-Stores muss diese Übersicht um vollständige Anbieteranschriften, Kontaktangaben, Rechtsgrundlagen, Speicherdauern und die jeweils eingesetzten Auftragsverarbeiter ergänzt werden.
