# ORION – Rohdaten und Quellcode

Das Downloadpaket `ORION-Quellcode-Rohdaten.zip` enthält den vollständigen bearbeitbaren Projektstand ohne Zugangsdaten, API-Schlüssel, Build-Ausgaben oder `node_modules`.

Enthalten sind:

- Web-/PWA-Quellcode (`app`, `lib`, `worker`, `db`)
- Styles, Manifest, Service Worker und öffentliche Grafiken
- Spectrum-X-Onboarding und Logo-Assets, 14 Sprachoberflächen, API-Erkennung/Modellkatalog/Sparprofile und sichtbares ORION-Gehirn
- Bildstudio, elf Radio-Sender inklusive PHONK, Stream-Chat-Copilot und Gamer-/Streamer-Control-Center
- Android-Quellprojekt mit Standby-, Sprache-, sichtbarer Gaming-Bildschirmfreigabe und Bedienungshilfen-Diensten
- Electron-Quellprojekt für Windows, macOS und Linux
- Capacitor-Grundprojekt für iOS/Android
- GitHub-Actions-Workflow zum Bauen von APK und Desktop-Installern
- Datenschutz-, Kosten-, Lizenz- und Installationsdokumentation
- Paketdateien, Build-Skripte und Tests

Nicht enthalten sind persönliche ORION-Nutzerdaten. Diese werden direkt in ORION über **Einstellungen → Meine Rohdaten** als `orion-backup.json` exportiert. Der Export enthält Chat, Gedächtnis, Befehle, Missionen, Timer, Gaming-Calls, Stream-Chat und Einstellungen, aber niemals den API-Key.

## Sicherheitsgrenze

ORION enthält keinen gemeinsamen Entwickler- oder OpenAI-API-Key. Nutzer wählen in derselben App zwischen persönlicher Puter-Anmeldung und einer eigenen OpenAI-kompatiblen API. Ein eingegebener Nutzer-Key wird nie exportiert oder in GitHub übernommen. Neural-Stimme, Gaming-Frame-Analysen und Online-Spracherkennung verwenden das persönliche Nutzerkonto. Absenden, „Jetzt kaufen“, Checkout und Bezahlen werden nicht automatisiert.
