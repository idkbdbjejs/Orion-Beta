import { OrionApp } from "./orion-app";

export default function Home() {
  return <OrionApp />;
}
