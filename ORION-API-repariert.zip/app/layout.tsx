import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ORION V1 Beta",
  description:
    "ORION – dein persönlicher KI-Assistent von Spectrum X für Desktop und Mobile.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/orion.svg",
    shortcut: "/orion.svg",
    apple: "/orion-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de">
      <head>
        <meta name="theme-color" content="#05090d" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="ORION" />
      </head>
      <body>{children}</body>
    </html>
  );
}
