import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "ORION V1 Beta",
    short_name: "ORION",
    description: "Dein Leben, dein Assistent, deine Zukunft.",
    start_url: "/",
    display: "standalone",
    background_color: "#05090d",
    theme_color: "#05090d",
    orientation: "any",
    categories: ["productivity", "utilities"],
    icons: [
      {
        src: "/orion.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        src: "/orion-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "maskable",
      },
      {
        src: "/orion-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
